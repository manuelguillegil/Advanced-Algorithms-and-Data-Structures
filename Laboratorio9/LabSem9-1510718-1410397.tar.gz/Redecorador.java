import java.util.*;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileReader;
import java.lang.Math;
import java.text.DecimalFormat;

/**Estudiantes:
 * Pietro Iaia 15-10718
 * Manuel Guillermo Gil 14-10397
 */

public class Redecorador { 

	/*Este metodo es utilizado por el main para Cargar el Grafo con los Vertices y sus Aristas
    */
	static Grafo cargarGrafo(String nombreArchivo, Grafo grafo)
			throws IOException
	{
		int n;                           // Corresponde al número de nodos del grafo
        int m;                       	 // Corresponde a la cantidad de aristas en el grafo

		BufferedReader Lector = new BufferedReader(
				new FileReader(nombreArchivo));
		
        String linea = Lector.readLine();
        n = Integer.parseInt(linea);

        /*Agregamos los vértices con las posiciones correspondientes*/
        for(int i = 0; i < n; i++){
        	linea = Lector.readLine();
        	String[] posiciones = linea.split(" ");
        	grafo.agregarVertice(i, Double.valueOf(posiciones[0]), Double.valueOf(posiciones[1]));
        }

        m = Integer.parseInt(Lector.readLine());      

        /*Ahora agregamos las aristas*/
        for(int i = 0; i < m; i++){
        	linea = Lector.readLine();
        	String[] vertices = linea.split(" ");
        	grafo.agregarArista(Integer.parseInt(vertices[0]), Integer.parseInt(vertices[1]));

        }
        return grafo; 
    }

    /*Este metodo es utilizado por el algoritmo Dijkstra para encontrar el Vertice Minimo
    */ 
    static Nodo ExtraerMin(ArrayList<Nodo> cola, Double[] Costo){
        Double Min = 9999999999999999.9;
        int MinElem = -1;
        /*Se busca el Vertice con Costo minimo en el arreglo Costo*/
        for(int i=0; i<cola.size(); i++){
            if(Costo[cola.get(i).getId()]<Min){
                Min = Costo[i];
                MinElem = i;
            }
        }
        /*Guardamos el Vertice Minimo en R y luego lo eliminamos de la cola*/
        Nodo R = cola.get(MinElem);
        cola.remove(MinElem);
        return R;

    }

    /*Metodo que calcula la Distancia Euclideana entre dos Vertices en el plano
    */ 
    static Double Costoe(Nodo V, Nodo W){
        return Math.sqrt(Math.pow(W.getX() - V.getX(), 2) + Math.pow(W.getY() - V.getY(), 2)); 
    }

    /*Este metodo es utilizado por el main con el Cual tomamos como atributos el Vertice final del camino a buscar, el arreglo de predecesores, El Grafo y el arreglo
    * de Costos de cada vertice. Luego el metodo retornara un string con el camino creado desde este vertice final y el vertice inicial del camino mas el numero de lados
    * y la distancia entre ellos
    */
    public static String EncontrarCamino(int Inicio, int[] Predecesor, Grafo Grafo, Double[] Costo){
        /*Inicializa las variables necesarias para el metodo*/
        int Pred = Predecesor[Inicio];
        String Camino = String.valueOf(Grafo.ListaVertices.get(Inicio).getId());
        int NumLados = 1;
        DecimalFormat numberFormat = new DecimalFormat("0.0#");

        while(true){
            if(Pred!=Predecesor[Pred]){                                                              //Si el predecesor del vertice no es el mismo
                Camino = String.valueOf(Grafo.ListaVertices.get(Pred).getId())+ "->"+Camino;
                Pred = Predecesor[Pred];
                NumLados++;
            }
            else{                                                                                    //Si el predecesor del vertice es el mismo, entonces este vertice es
                break;                                                                               //el vertice inicial del camino
            }
        }
        Camino = String.valueOf(Grafo.ListaVertices.get(Pred).getId())+ "->"+Camino;                 //Agrega el Vertice inicial a el String con el camino.
        Camino = "    Nodo "+String.valueOf(Inicio)+": "+Camino+"   "+"\t"+String.valueOf(NumLados)+" Lados"+" (Costo "+String.valueOf(numberFormat.format(Costo[Inicio]))+")";
        return Camino;
    }



    //###########################################################################  A*  ###########################################################################

    /*Este metodo escoge el nodo con valor F mas pequeño en la Lista de Abiertos
    */
    static Nodo SeleccionarA(ArrayList<Nodo> Abiertos){                                                                 
        Nodo Menor = Abiertos.get(0);                                                              //Inicializamos el Menor vertice
        Double FMenor = 9999999999.0;                                                              //Inicializamos el valor del menor vertice
        for(int i=0; i<Abiertos.size(); i++){      
            /*Si el vertice es menor que el vertice menor encontrado hasta ahora, lo actualiza*/ 
            if(Abiertos.get(i).getF()<FMenor){
                Menor = Abiertos.get(i);
                FMenor = Abiertos.get(i).getF();
            }
        }
        /*Remueve de Abiertos a el Vertice Tomado*/
        int i = 0;
        while(i<Abiertos.size()){
            if(Menor.getId() == Abiertos.get(i).getId()){
                Abiertos.remove(i);
            }
            else{
                i++;
            }
        }

        return Menor;
    }

    /*Calcula, para cada vertice, Su distancia media desde el a el vertice final del recorrido
    */
    static void SetHs(Nodo VFinal, Grafo grafo){
        for(int i=0; i<grafo.ListaVertices.size(); i++){
            grafo.ListaVertices.get(i).SetH(VFinal.getX(), VFinal.getY());
        }
    }

    /*Resetea los parametros de h(x), g(x), f(x) para cada nodo para ua nueva iteracion de A*
    */
    static void ResetNodos(Grafo grafo){
        for(int i=0; i<grafo.ListaVertices.size(); i++){
            grafo.ListaVertices.get(i).resetH();
            grafo.ListaVertices.get(i).resetF();
            grafo.ListaVertices.get(i).resetG();
        }
    }

    /*Esta funcion la llamamos para hacerle Print a los resultados de la corrida de un A* 
    */
    static void PrintOutput(ArrayList<Nodo> Abiertos, ArrayList<Nodo> Cerrados, Grafo grafo, long endTime, long StartTime, Nodo Final, Nodo Origen){

        DecimalFormat numberFormat = new DecimalFormat("0.0#");

        System.out.println("    Numero de Vertices Abiertos: "+String.valueOf(Abiertos.size()));
        System.out.println("    Numero de Vertices Cerrados: "+String.valueOf(Cerrados.size()));

        int Contador = 0;
        for(int i=0; i<grafo.ListaVertices.size(); i++){
            if(!Cerrados.contains(grafo.ListaVertices.get(i))){
                Contador++;
            }
        }
        System.out.println("    Numero de Vertices No Visitados: "+String.valueOf(Contador));

        String Camino ="";
        Contador = 0;
        ReconstruirA(Final, Origen, Camino, Final, Contador);                                                      //Aqui reconstruimos el camino

        System.out.println("    Tiempo de ejecucion del algoritmo: "+String.valueOf(endTime - StartTime));
    }

    /*Este metodo es usado por el Algoritmo de A* para Recontruir el Camino formado desde el Vertice Origen hasta el Final, lo hace de manera recursiva
    */
    static void ReconstruirA(Nodo Final, Nodo Origen, String Camino, Nodo FinalV, int Contador){
        DecimalFormat numberFormat = new DecimalFormat("0.0#");

        if(Origen.getId() == Final.getId()){
            Camino = "    Nodo "+String.valueOf(FinalV.getId())+": "+String.valueOf(Origen.getId())+ Camino;
            Camino = Camino +"\t"+String.valueOf(Contador)+" Lados"+" (Costo "+String.valueOf(numberFormat.format(FinalV.getF()))+")";
            System.out.println(Camino);
        }
        else{
            Camino = "->" + String.valueOf(Final.getId()) + Camino;
            Contador++;
            ReconstruirA(Final.getPadre(), Origen, Camino, FinalV, Contador);
        }
    }

    //############################################################################################################################################################



	public static void main(String[] args)
		throws IOException, IllegalArgumentException
	{

        System.out.println("\nAlgoritmo Dijkstra:");
        long startTime = System.nanoTime();
		Grafo grafo = new Grafo();                                                     //Crea el objeto Grafo
        grafo = cargarGrafo(args[0], (Grafo)grafo);                                    //Carga el Grafo

        /*Inicializa todos los arreglos y variables necesarias para correr Dijkstra*/
        int[] P = new int[grafo.ListaVertices.size()];         
        Double[] Costo = new Double[grafo.ListaVertices.size()];
        ArrayList<Nodo> cola = new ArrayList<Nodo>();                                                 //Lista de Abiertos de Dijkstra
        ArrayList<Nodo> CerradosD = new ArrayList<Nodo>();                                            //Lista de Cerrados de Dijkstra
        Nodo V;
        Nodo W;

        for(int i=0; i<grafo.ListaVertices.size(); i++){        
            P[i] = -1;                                                  //Se inicializa el arreglo en -1.
            cola.add(grafo.ListaVertices.get(i));
            Costo[i] = 99999999999.9;
        }
        Costo[Integer.parseInt(args[1])] = 0.0;
        P[Integer.parseInt(args[1])] = Integer.parseInt(args[1]);

        /*Aqui es donde comienza la ejecucion del Dijkstra*/
        while(cola.size()!=0){
            V = ExtraerMin(cola, Costo);                                                              //Vertice minimo en la cola
            CerradosD.add(V);
            for(int i=0; i<grafo.ListaVertices.get(V.getId()).ListaAdy.size(); i++){
                W = grafo.ListaVertices.get(V.getId()).ListaAdy.get(i);                               //Vertice adyacente a V
                /*Serian dos casos if ya que estamos en un grafo no dirigido por ende la arista funciona como un arco con doble sentido*/
                if(Costo[W.getId()] > Costo[V.getId()] + Costoe(V, W)){
                    Costo[W.getId()] = Costo[V.getId()] + Costoe(V, W);
                    P[W.getId()] = V.getId();
                }
                else if(Costo[V.getId()] > Costo[W.getId()] + Costoe(V, W)){
                    Costo[V.getId()] = Costo[W.getId()] + Costoe(V, W);
                    P[V.getId()] = W.getId();
                }
            }
        }
        long endTime = System.nanoTime();

        /*Luego de correr Dijkstra y tener el arreglo de predecesores y Costos, pasamos a encontrar los caminos para luego imprimirlos*/
        for(int i=0; i<P.length; i++){
            System.out.println("\n\nCamino desde "+String.valueOf(args[1])+" Hasta "+String.valueOf(i)+":");
            System.out.println("    Numero de Vertices Abiertos: "+String.valueOf(cola.size()));
            System.out.println("    Numero de Vertices Cerrados: "+String.valueOf(CerradosD.size()));

            int Contador = 0;
            for(int j=0; j<P.length; j++){
                if(P[j]==-1){
                    Contador++;
                }
            }
            System.out.println("    Numero de Vertices no Visitados: "+String.valueOf(Contador));

            if(P[i]!=i){
                if(P[i]==-1){
                    System.out.println("    *No existe camino Desde el vertice inicial hasta este Vertice*");
                }
                else{
                    System.out.println(EncontrarCamino(i, P, grafo, Costo));
                }
            }
            /*Este else lo usamos cuando nos toca imprimir el camino hasta el Vertice S con el que corrimos Dijkstra
            * ya que en EncontrarCamino no tomamos en cuenta este caso*/
            else{
                System.out.println("    Nodo "+String.valueOf(i)+": "+String.valueOf(i)+"   "+"\t"+String.valueOf(0)+" Lados"+" (Costo "+String.valueOf(Costo[i])+")");
            }
            System.out.println("    Tiempo de ejecucion: "+String.valueOf(endTime - startTime));
        }

        System.out.println("\n\n");
        System.out.println("Algoritmo A*:\n");



        //###########################################################################  A*  ###########################################################################

        /*####### NOTA: Numero de vertices no Visitados: Tome en cuenta los vertices del grafo que NO estan en el conjunto de Cerrados, ya que A* los tomo 
        * en cuenta y los recorrio, pero pudo haber seleccionado otro camino mas adelante por ello no aparece en el camino final, pero A* si lo recorrio #######*/

        /*Nodo Origen de los recorridos, dado por el usuario*/
        Nodo Origen = grafo.ListaVertices.get(Integer.parseInt(args[1]));

        /*Hacemos este ciclo para encontrar todos los caminos minimos desde un vertice dado hasta sus alcanzables usando A* */
        for(int i=0; i<grafo.ListaVertices.size(); i++){
            startTime = System.nanoTime();                                                                           //Inicializamos el tiempo

            System.out.println("Camino desde "+String.valueOf(args[1])+" Hasta "+String.valueOf(i)+":");

            if(Origen.getId() != i){
                if(grafo.ListaVertices.get(i).ListaAdy.size()==0 || Origen.ListaAdy.size()==0){
                    System.out.println("    *No existe camino Desde el vertice inicial hasta este Vertice*\n");
                    continue;
                }
            }

            ResetNodos(grafo);                                                                                       //Resetea los parametros de los Vertices
            SetHs(grafo.ListaVertices.get(i), grafo);                                                                //Calcula las h(x) para cada nodo en este recorrido

            ArrayList<Nodo> Abiertos = new ArrayList<Nodo>();                                                        //Inicializa La lista de Abiertos
            Abiertos.clear();
            Abiertos.add(grafo.ListaVertices.get(Integer.parseInt(args[1])));                                        //Agrega el vertice inicial a Abiertos
            ArrayList<Nodo> Cerrados = new ArrayList<Nodo>();                                                        //Inicializa la lista de Cerrados
            Cerrados.clear();

            /*Correr A* hasta que la lista de Abiertos sea vacia*/
            while(Abiertos.size()!=0){
                V = SeleccionarA(Abiertos);                                                                          //Selecciona un V con valor f(x) minimo de la lista de Abiertos                                                        
                Cerrados.add(V);                                                                                     //Se agrega este V a la lista de Cerrados

                if(V.getId() == grafo.ListaVertices.get(i).getId()){
                    endTime = System.nanoTime();                                                                     //Se toma el tiempo de salida
                    PrintOutput(Abiertos, Cerrados, grafo, endTime, startTime, V, Origen);                           //Se llama a la funcion que hace print al resultado
                    System.out.println("\n");                     
                    break;                                                                                           //break para Terminar la ejecucion de A*
                }

                /*Para cada alcanzable de V*/
                for(int j=0; j<V.ListaAdy.size(); j++){
                    /*Si el alcanzable de V no esta en Cerrados, lo agrega a la lista de Abiertos*/
                    if(!Cerrados.contains(V.ListaAdy.get(j))){
                        V.ListaAdy.get(j).SetG(V.getG() + Costoe(V, V.ListaAdy.get(j)));                             //Se calcula la g(x) de este Vertice
                        V.ListaAdy.get(j).SetF();                                                                    //Se calcula la f(x) de este Vertice
                        V.ListaAdy.get(j).setPadre(V);                                                               //Predecesor del alcanzable de V es V, para luego reconstruir el camino
                        Abiertos.add(V.ListaAdy.get(j));                                                             //Se agrega el Vertice a la lista de Abiertos
                    }
                }
            }

            //########################################################################################################################################################
        }
	}
}