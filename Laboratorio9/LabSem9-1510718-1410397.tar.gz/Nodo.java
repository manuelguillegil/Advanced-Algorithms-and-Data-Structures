/**Estudiantes:
 * Pietro Iaia 15-10718
 * Manuel Guillermo Gil 14-10397
 */

import java.util.*;

public class Nodo{
 
    /*Atributos:
    * id: Identificador del Vertice, sera un entero
    * x: Posicion en el plano x del vertice
    * y: Posicion en el plano y del vertice
    * h: Distancia estimada desde este vertice al vertice final del Recorrido
    * g: Distancia real desde este vertice al vertice inicial del Recorrido
    * f: Funcion utilizada por el Algoritmo A*
    * Padre: Vertice predecesor a este Vertice en el recorrido en el Algoritmo A*
    * ListaAdy: Lista de vertices adyacentes a este Vertice.
    */
    int id;
    Double x;
    Double y;
    Double h;
    Double g;
    Double f;
    Nodo Padre;
    ArrayList<Nodo> ListaAdy;

    /*Constructor de la clase, inicializa los atributos
    */
    public Nodo(int identificador, double x, double y){
        this.id = identificador;                                           
        this.x = x;
        this.y = y;
        this.ListaAdy = new ArrayList<Nodo>();
    }

    /*Devuelve el identificador del vertice
    */
     public int getId(){
        return this.id;
    }

    /*Devuelve la posicion en el plano x del vertice
    */
    public Double getX(){
      return this.x;
    }

    /*Devuelve la posicion en el plano y del vertice
    */
    public Double getY(){
       return this.y;
    }

    /*Ingresa el valor de h(Nodo)
    */ 
    public void SetH(Double X2, Double Y2){
        this.h = Math.sqrt(Math.pow(X2 - this.x, 2) + Math.pow(Y2 - this.y, 2));
    }

    /*Ingresa el valor de g(Nodo)
    */ 
    public void SetG(Double i){
        this.g = i;
    }

    /*Ingresa el valor de f(Nodo)
    */ 
    public void SetF(){
        this.f = this.h + this.g;
    }

    /*Obtiene el valor de h(Nodo)
    */
    public Double getH(){
        return this.h;
    }

    /*Obtiene el valor de f(Nodo)
    */
    public Double getF(){
        return this.f;
    }

    /*Obtiene el valor de g(Nodo)
    */
    public Double getG(){
        return this.g;
    }

    /*Vuelve a 0 el valor de h(Nodo)
    */
    public void resetH(){
        this.h = 0.0;
    }

    /*Vuelve a 0 el valor de f(Nodo)
    */
    public void resetF(){
        this.f = 0.0;
    }

    /*Vuelve a 0 el valor de g(Nodo)
    */
    public void resetG(){
        this.g = 0.0;
    }

    /*Ingresa el valor de Pade del nodo 
    */
    public void setPadre(Nodo V){
        this.Padre = V;
    }

    /*Devuelve el valor de Pade del nodo 
    */
    public Nodo getPadre(){
        return this.Padre;
    }



}